rootProject.name = "azmz-backend"
